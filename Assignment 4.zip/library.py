import hash_table as ht

class DigitalLibrary:
    # DO NOT CHANGE FUNCTIONS IN THIS BASE CLASS
    def __init__(self):
        pass
    
    def distinct_words(self, book_title):
        pass
    
    def count_distinct_words(self, book_title):
        pass
    
    def search_keyword(self, keyword):
        pass
    
    def print_books(self):
        pass
    
class MuskLibrary(DigitalLibrary):
    def __init__(self, book_titles, texts):
        # Pair each title with its corresponding text in a list of tuples
        super().__init__()
        book_title_text_pairs = [(book_titles[i], texts[i]) for i in range(len(book_titles))]

        # Sort the pairs by book title
        sorted_pairs = self._merge_sort(book_title_text_pairs, key=lambda x: x[0])

        # Initialize the book_titles and texts lists
        self.book_titles, self.texts = [], []

        # Process each sorted pair, removing duplicates and sorting the words in each text
        for title, text in sorted_pairs:
            self.book_titles.append(title)
            # Remove duplicates from text and sort the words lexicographically
            unique_words = self._remove_duplicates(text)
            sorted_words = self._merge_sort(unique_words)
            self.texts.append(sorted_words)

    def _remove_duplicates(self, words):
        unique_words = []
        for word in words:
            if word not in unique_words:
                unique_words.append(word)
        return unique_words

    def _binary_search(self, sorted_words, keyword):
        left, right = 0, len(sorted_words) - 1
        while left <= right:
            mid = (left + right) // 2
            if sorted_words[mid] == keyword:
                return True
            elif sorted_words[mid] < keyword:
                left = mid + 1
            else:
                right = mid - 1
        return False

    def _merge_sort(self, arr, key=lambda x: x):
        if len(arr) <= 1:
            return arr
        mid = len(arr) // 2
        left = self._merge_sort(arr[:mid], key=key)
        right = self._merge_sort(arr[mid:], key=key)
        return self._merge(left, right, key)

    def _merge(self, left, right, key):
        sorted_list = []
        i = j = 0
        while i < len(left) and j < len(right):
            if key(left[i]) < key(right[j]):
                sorted_list.append(left[i])
                i += 1
            else:
                sorted_list.append(right[j])
                j += 1
        sorted_list.extend(left[i:])
        sorted_list.extend(right[j:])
        return sorted_list
        
    def _binary_search_1(self, sorted_words, keyword):
        left, right = 0, len(sorted_words) - 1
        while left <= right:
            mid = (left + right) // 2
            if sorted_words[mid] == keyword:
                return mid
            elif sorted_words[mid] < keyword:
                left = mid + 1
            else:
                right = mid - 1
        return -1

    def distinct_words(self, book_title):
        if self._binary_search(self.book_titles,book_title):
            index = self._binary_search_1(self.book_titles,book_title)
            return self.texts[index]
        return []

    def count_distinct_words(self, book_title):
        if self._binary_search(self.book_titles,book_title):
            index = self._binary_search_1(self.book_titles,book_title)
            return len(self.texts[index])
        return 0

    def search_keyword(self, keyword):
        titles_with_keyword = []
        for i in range(len(self.texts)):
            if self._binary_search(self.texts[i], keyword):
                titles_with_keyword.append(self.book_titles[i])
        return titles_with_keyword

    def print_books(self):
        for i, title in enumerate(self.book_titles):
            words_str = " | ".join(self.texts[i])
            print(f"{title}: {words_str}")


class JGBLibrary(DigitalLibrary):
    # IMPLEMENT ALL FUNCTIONS HERE
    def __init__(self, name, params):
        '''
        name    : "Jobs", "Gates" or "Bezos"
        params  : Parameters needed for the Hash Table:
            z is the parameter for polynomial accumulation hash
            Use (mod table_size) for compression function
            
            Jobs    -> (z, initial_table_size)
            Gates   -> (z, initial_table_size)
            Bezos   -> (z1, z2, c2, initial_table_size)
                z1 for first hash function
                z2 for second hash function (step size)
                Compression function for second hash: mod c2
        '''
        super().__init__()
        
        self.name = name

        if name == "Jobs":
            self.books = ht.HashMap("Chain", params)
            self.word_hash_type = "Chain"
        elif name == "Gates":
            self.books = ht.HashMap("Linear", params)
            self.word_hash_type = "Linear"
        elif name == "Bezos":
            self.books = ht.HashMap("Double", params)
            self.word_hash_type = "Double"
        self.params = params
    
    def add_book(self, book_title, text):
        word_set = ht.HashSet(self.word_hash_type, self.params)

        for word in text:
            word_set.insert(word)
        self.books.insert((book_title, word_set))
    
    def distinct_words(self, book_title):
        word_set = self.books.find(book_title)
        if word_set is not None:
            return word_set.get_all_items()
        return []
    
    def count_distinct_words(self, book_title):
        word_set = self.books.find(book_title)
        if word_set is not None:
            return word_set._n 
        return 0
    
    def search_keyword(self, keyword):
        titles_with_keyword = []
        for book_title, word_set in self.books.get_all_items():
            if word_set.find(keyword):
                titles_with_keyword.append(book_title)
        return titles_with_keyword
    
    def print_books(self):
        for book_title, word_set in self.books.get_all_items():
            print(f"{book_title}: {word_set}")