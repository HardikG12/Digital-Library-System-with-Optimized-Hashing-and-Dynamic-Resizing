from prime_generator import get_next_size

class HashTable:
    def __init__(self, collision_type, params):
        '''
        Possible collision_type:
            "Chain"     : Use hashing with chaining
            "Linear"    : Use hashing with linear probing
            "Double"    : Use double hashing
        '''
        
        if collision_type == "Chain" or collision_type == "Linear":
            self.table_size = params[1]
            self._table = self.table_size*[None]
            self._n = 0
            self._z = params[0]
        
        else:
            self.table_size = params[3]
            self._table = self.table_size*[None]
            self._n = 0
            self._z = params[0]
            self._ztwo = params[1]
            self._ctwo = params[2]
            
        self._collision_type = collision_type
        
    def _hash(self, key):
        hash_value = 0
        for i in range(len(key)-1,-1,-1):
            p_value = ord(key[i]) - ord('a') if 'a' <= key[i] <= 'z' else ord(key[i]) - ord('A') + 26
            hash_value = (hash_value*self._z + p_value)%self.table_size
            
        return (hash_value) % self.table_size

    def _double_hash(self, key):
        hash_value = 0
        for i in range(len(key)-1,-1,-1):
            p_value = ord(key[i]) - ord('a') if 'a' <= key[i] <= 'z' else ord(key[i]) - ord('A') + 26
            hash_value = (hash_value*self._ztwo + p_value)%self._ctwo

        return (self._ctwo - (hash_value)) % self.table_size
        
    def insert(self, x):
        
        slot = self._hash(x[0] if isinstance(x, tuple) else x)
        start_slot = slot
        
        
        
        if self._collision_type == "Chain":
            
            if self._table[slot] is None:
                self._table[slot] = []
            if x not in self._table[slot]:
                self._table[slot].append(x)
                self._n += 1
                
        elif self._collision_type == "Linear":
            if self._n == self.table_size:
                raise Exception("Table is full")
            
            while self._table[slot] is not None:
                
                if self._table[slot] == x:
                    return  # Duplicate, do not insert
                slot = (slot + 1) % self.table_size
                
                if(slot == start_slot):
                    return
                
            self._table[slot] = x
            self._n += 1
            
        elif self._collision_type == "Double":
            if self._n == self.table_size:
                raise Exception("Table is full")
            step = self._double_hash(x[0] if isinstance(x, tuple) else x)
            
            while self._table[slot] is not None:
                
                if self._table[slot] == x:
                    return  # Duplicate, do not insert
                slot = (slot + step) % self.table_size
                
                if(slot == start_slot):
                    return
                
            self._table[slot] = x
            self._n += 1
    
    def find(self, key):
        
        slot = self._hash(key)
        start_slot = slot
        
        if self._collision_type == "Chain":
            return key in self._table[slot] if self._table[slot] else False
            
        elif self._collision_type == "Linear":
            
            while self._table[slot] is not None:
                if self._table[slot] == key:
                    return True
                slot = (slot + 1) % self.table_size
                if(slot == start_slot):
                    break
            return False
            
        elif self._collision_type == "Double":
            
            step = self._double_hash(key)
            while self._table[slot] is not None:
                if self._table[slot] == key:
                    return True
                slot = (slot + step) % self.table_size
                if(slot == start_slot):
                    break
            return False
    
    def get_slot(self, key):
        
        slot = self._hash(key)
        return slot
    
    def get_load(self):
        
        return self._n / self.table_size
    
    def __str__(self):
        
        result = []
        for slot in self._table:
            if slot is None:
                result.append("⟨EMPTY⟩")
            elif isinstance(slot, list):
                result.append(" ; ".join(str(item) for item in slot))
            elif isinstance(slot, tuple):
                result.append(f"({slot[0]}, {slot[1]})")
            else:
                result.append(str(slot))
        return " | ".join(result)
        
    # TO BE USED IN PART 2 (DYNAMIC HASH TABLE)
    def rehash(self):
        pass
    
# IMPLEMENT ALL FUNCTIONS FOR CLASSES BELOW
# IF YOU HAVE IMPLEMENTED A FUNCTION IN HashTable ITSELF, 
# YOU WOULD NOT NEED TO WRITE IT TWICE
    
class HashSet(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, key):
        super().insert(key)

    def find(self, key):
        return super().find(key)

    def get_slot(self, key):
        return super().get_slot(key)

    def get_load(self):
        return super().get_load()
    
    def get_all_items(self):
        items = []
        for slot in self._table:
            if slot is not None:
                if isinstance(slot, list): 
                    items.extend(slot)
                else:
                    items.append(slot)
        return items

    def __str__(self):
        result = []
        for slot in self._table:
            if slot is None:
                result.append("<EMPTY>")
            elif isinstance(slot, list):
                result.append(" ; ".join(str(item) for item in slot))
            else:
                result.append(str(slot))
        return " | ".join(result)

class HashMap(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, x):
        key, value = x 
        slot = self._hash(key)
        start_slot = slot

        if self._collision_type == "Chain":
            if self._table[slot] is None:
                self._table[slot] = []
            for i, item in enumerate(self._table[slot]):
                if item[0] == key:
                    self._table[slot][i] = (key, value) 
                    return
            self._table[slot].append((key, value))
            self._n += 1

        elif self._collision_type == "Linear":
            if self._n == self.table_size:
                raise Exception("Table is full")
            while self._table[slot] is not None:
                if self._table[slot][0] == key:
                    self._table[slot] = (key, value)
                    return
                slot = (slot + 1) % self.table_size
                if slot == start_slot:
                    return 
            self._table[slot] = (key, value)
            self._n += 1

        elif self._collision_type == "Double":
            if self._n == self.table_size:
                raise Exception("Table is full")
            step = self._double_hash(key)
            while self._table[slot] is not None:
                if self._table[slot][0] == key:
                    self._table[slot] = (key, value)
                    return
                slot = (slot + step) % self.table_size
                if slot == start_slot:
                    return
            self._table[slot] = (key, value)
            self._n += 1
        

    def find(self, key):
        slot = self._hash(key)
        start_slot = slot

        if self._collision_type == "Chain":
            if self._table[slot] is not None:
                for item in self._table[slot]:
                    if item[0] == key:
                        return item[1]
            return None

        elif self._collision_type == "Linear":
            while self._table[slot] is not None:
                if self._table[slot][0] == key:
                    return self._table[slot][1]
                slot = (slot + 1) % self.table_size
                if slot == start_slot:
                    break
            return None

        elif self._collision_type == "Double":
            step = self._double_hash(key)
            while self._table[slot] is not None:
                if self._table[slot][0] == key:
                    return self._table[slot][1]
                slot = (slot + step) % self.table_size
                if slot == start_slot:
                    break
            return None

    def get_slot(self, key):
        return super().get_slot(key)

    def get_load(self):
        return super().get_load()

    def __str__(self):
        result = []
        for slot in self._table:
            if slot is None:
                result.append("⟨EMPTY⟩")
            elif isinstance(slot, list):
                result.append(" ; ".join(f"({item[0]}, {item[1]})" for item in slot))
            elif isinstance(slot, tuple):
                result.append(f"({slot[0]}, {slot[1]})")
            else:
                result.append(str(slot))
        return " | ".join(result)

    def get_all_items(self):
        items = []
        for slot in self._table:
            if slot is not None:
                if isinstance(slot, list):
                    items.extend(slot)
                else:
                    items.append(slot)
        return items